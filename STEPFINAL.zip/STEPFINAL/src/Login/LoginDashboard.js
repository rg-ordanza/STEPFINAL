import React from 'react';
import Login from './Login';
import './style.css'

const LoginDashboard = (props) => {
    return (
        <div className="login-dashboard">
            <Login isAdmin={props.isAdmin} isAuthenticated={props.isAuthenticated}/>
        </div>
    );
}

export default LoginDashboard;
