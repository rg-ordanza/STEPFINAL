import React from 'react';
import './style.css';
import axios from 'axios';
import qs from 'qs';
import {Redirect} from 'react-router-dom';


class Login extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            username: '',
            password: '',
            redirect: false
        }

        this.usernameChangeHandler = e => {
            this.setState({username: e.target.value});
        }

        this.passwordChangeHandle = e => {
            this.setState({password: e.target.value});
        }

        this.submitData = () => {
            let parameters = {
                user: this.state.username,
                pass: this.state.password
            }
              
              const config = {
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                }
              }
              
              axios.post("http://sheltered-chamber-92543.herokuapp.com/login", qs.stringify(parameters), config)
                .then((result) => {
                    if(result.data) {
                        this.props.isAuthenticated();
                    }
                    this.setState({username: '', password: ''});
                })
                .catch((err) => {
                    console.log(err);
                })
        }
        
        this.toggleType = (inputPassword) => {
            if(inputPassword.type === "password") {
                inputPassword.type = "text";
            } else {
                inputPassword.type = "password";
            }
        }

     
    }

    render() {
        if(this.props.isAdmin) {
            return <Redirect to='/announcements' />
        }
        
        return (
            <div className="container-fluid login-container">
                <div className="row justify-content-center">
                    <div className="col-md-4 login-content-container">
                        <div className="contents">
                            <div className="login-title">Login</div>
                            <div className="mt-2">
                                <i className="fas fa-user"></i>
                                <input value={this.state.username} onChange={this.usernameChangeHandler} className="username-input" type="text" name="username" placeholder="Username"/>
                            </div>
                            <div className="mt-3">
                                <i className="fas fa-user-lock"></i>
                                <input value={this.state.password} onChange={this.passwordChangeHandle} className="password-input" type="password" id="password" name="password" placeholder="Password"/>
                                <i onClick={() => {this.toggleType(document.getElementById('password'))}} className="fas fa-eye"></i>
                            </div>
                            <button onClick={this.submitData} className="mt-4 myButton">Login as admin</button>
                            <div className="mt-3 text-light text-center">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Login;
