import React from 'react';
import './style.css';

const Footer = () => {
    return (
        <div className="container-fluid mt-5">
            <div className="row">
                <footer className="col-md-12 p-3">
                    <div className="row">
                        <footer className="col-md-6">
                            <span className="created-for">This page was created for San Jose National High School. &copy; 2018</span>
                        </footer>
                        <footer className="col-md-6 text-right">
                            <span className="created-for">Contributors: Ryan Gwen Ordanza, Christian Abuel, Jon Paulo Ambrocio</span>
                        </footer>
                    </div>
                </footer>
            </div>            
        </div>
    );
}

export default Footer;
