import React, {Fragment, Component} from 'react';
import Navigation from './Navigation/Navigation';
import Footer from './Footer/Footer';

class HOC extends Component {
    render() {
        return (
            <Fragment>
                <Navigation activeRoute={this.props.activeRoute}/>
                    {this.props.children}
                <Footer />
            </Fragment>
        );
    }
}

export default HOC;
