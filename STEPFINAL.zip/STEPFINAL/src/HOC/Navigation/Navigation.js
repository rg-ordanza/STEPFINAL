import React from 'react';
import './style.css';

class Navigation extends React.Component {
    
    constructor(props){
        super(props);
        this.state = {
            isAdmin: false
        }
    }

    onClickHandler = gradelevel => {
        localStorage.setItem('gradeLevel', gradelevel)
    }

    componentDidMount() {
        let isAdministrator = localStorage.getItem('isAdmin');
        if(JSON.parse(isAdministrator)) {
            this.setState({isAdmin: true});
        }
    }

    logout = () => {
        localStorage.clear();
    }

    render() {
        return (
            <div className="container-fluid navigation">
                <div className="row nav-container">
                    <div className="col-md-4">
                        <img className="logo" src="./jjj.png" alt="logo"/>
                        <li className="breadcrum">/ <a href="/#/">{this.props.activeRoute}</a></li>
                    </div>
                    <div className="navigation-items">
                        <li onClick={this.Home}><a href="/#/">Home</a></li>
                        <li onClick={this.Announcement}><a href="/#/announcements">Announcement</a></li>
                        <li onClick={this.Accomplishments}><a href="/#/accomplishments">Accomplishment</a></li>
                        <li className="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Students
                        </li>
                        <div className="dropdown-menu dropdown-menu-right">
                            <li className="dropdown-item"><a className="text-dark" onClick={() => this.onClickHandler(7)} href="/#/grade7">Grade 7</a></li>
                            <li className="dropdown-item"><a className="text-dark" onClick={() => this.onClickHandler(8)} href="/#/grade8">Grade 8</a></li>
                            <li className="dropdown-item"><a className="text-dark" onClick={() => this.onClickHandler(9)} href="/#/grade9">Grade 9</a></li>
                            <li className="dropdown-item"><a className="text-dark" onClick={() => this.onClickHandler(10)} href="/#/grade10">Grade 10</a></li>
                        </div>
                        {this.state.isAdmin ? 
                            <li onClick={this.logout}><a href="/#/home">Logout</a></li>
                            : null
                        }   
                    </div>
                </div>
            </div>
        );
    }
}

export default Navigation;
