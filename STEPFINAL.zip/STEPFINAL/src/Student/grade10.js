import React, { Component } from 'react'
import HOC from '../HOC/index';
import StudentForm from './StudentForm';
import StudentsTable from './StudentsTable';
import { Table } from 'reactstrap';
import axios from 'axios';

export default class Student extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data:[],
      toggleState: true,
      isAdmin: false
    }

    this.reloadState = () => {
      if(this.toggleState) this.setState({toggleState: false});
      else this.setState({toggleState: true});
      this.getData();
  }
    
    this.getData = () => {
      axios.get("http://sheltered-chamber-92543.herokuapp.com/students?gradeLevel=10")
            .then((result) => {
              this.setState({data: result.data})
            })
            .catch((err) => {
                console.log(err);
            });
    }
  } 

  componentDidMount() {
    this.getData();
    let isAdministrator = localStorage.getItem('isAdmin');
    if(JSON.parse(isAdministrator)) {
        this.setState({isAdmin: true});
    }
  }

  render() {
    let studentsAttendance = this.state.data.map((val, ind) => {
      return <StudentsTable id={ind} reloadState={this.reloadState} data={val} key={ind} />
    }); 
    return (
      <div>
        <HOC activeRoute={"Students / grade10"}>
            {this.state.isAdmin ? 
              <StudentForm reloadState={this.reloadState} /> 
            : null }
            <div className="container mt-5">
              <div className="row justify-content-center">
                <div className="col-md-8">
                  <Table bordered>
                      <thead>
                          <tr>
                              <td>No.</td>        
                              <td>Name</td>
                              <td>Attendance</td>
                              <td>Date</td>
                              {this.state.isAdmin ? 
                                <td>Controls</td>
                              : null }
                              
                          </tr>
                          </thead>
                          {studentsAttendance}
                  </Table>
                </div>
            </div>
          </div>
        </HOC>
      </div>
    )
  }
}
