import React, { Component, Fragment } from 'react'
import './style.css';
import moment from 'moment';
import axios from 'axios';
import qs from 'qs';

export default class StudentsTable extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            isAdmin: false, 
            name: this.props.data.name,
            attendance: 0,
            id: this.props.data._id
        }

        this.nameChangeHanlder =e  => {
            this.setState({name: e.target.value});
        }
    }

    onSelectChange = e => {
        this.setState({attendance: e.target.value});
    }

    updateData = () => {
        let parameters = {
            id: this.props.data._id,
            name: this.state.name,
            attendance: this.state.attendance
        }
        const config = {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
        axios.post("http://sheltered-chamber-92543.herokuapp.com/studentsupdate", qs.stringify(parameters) , config)
        this.props.reloadState();
        alert('updated!');
    }

    deleteData = () => {
        const config = {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            }
          }
          axios.post("http://sheltered-chamber-92543.herokuapp.com/studentsdelete", qs.stringify({id: this.state.id}) , config);
          this.props.reloadState();
          alert('Removed!');
    }

    componentDidMount() {
        let isAdministrator = localStorage.getItem('isAdmin');
        if(JSON.parse(isAdministrator)) {
            this.setState({isAdmin: true});
        }
    }

  render() {
    return (
        <Fragment>
            <tr>
                <td>{this.props.id + 1}</td>
                {this.state.isAdmin ? <td><input className="mt-3 form-control align-self-center" value={this.state.name} onChange={this.nameChangeHanlder}/></td> : <td>{this.props.data.name}</td>}
                {this.state.isAdmin ? 
                    <td><select onChange={this.onSelectChange} className="custom-select">
                        <option value={null}>Attendance</option>
                        <option value={1}>Present</option>
                        <option value={0}>Absent</option>
                    </select></td>
                    :
                    <td>{this.props.data.attendance ===1 ? "Present" : "Absent" }</td>
                }
                <td>{moment(this.props.data.date).format("MMMM Do YYYY")}</td>
            {this.state.isAdmin ? 
            <td className="control-btn">
                <button onClick={this.updateData} className="mr-2 btn-warning btn-sm btn">Update</button>
                <button onClick={this.deleteData} className="buttonStyle btn btn-sm btn-success mt-1">Delete</button>
            </td>
            : null }
            </tr>
        </Fragment>
    )
  }
}
