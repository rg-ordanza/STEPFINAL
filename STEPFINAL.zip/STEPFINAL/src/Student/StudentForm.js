import React, { Component } from 'react'
import './style.css';
import axios from 'axios';
import qs from 'qs';

export default class StudentForm extends Component {

    constructor(props) {
        super(props);
        this.state = {
            name: '',
            attendance: null
        }
        this.onClickHandler = () => {
            let parameters = {
                name: this.state.name,
                attendance: this.state.attendance,
                gradeLevel: localStorage.getItem('gradeLevel')
            }
              
            const config = {
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
            }
            
            axios.post("http://sheltered-chamber-92543.herokuapp.com/students", qs.stringify(parameters) , config)
              .then((result) => {
                this.setState({name: ''});
                this.props.reloadState();
              })
              .catch((err) => {
                  console.log(err);
              });
              this.setState({name: ''});
              this.props.reloadState();
              alert('Submitted!');
        }

        this.onSelectChange = e => {
            this.setState({attendance: e.target.value});
        } 
    }
    
    
  render() {
    return (
      <div className="student-form container mt-5">
        <div className="row justify-content-center">
            <div className="col-md-4">
                <input value={this.state.name} onChange={e => this.setState({name: e.target.value})} className="form-control" name="student-name" placeholder="Student name..." type="text"/>
            </div>
            <div className="col-md-2">
                <select onChange={this.onSelectChange} className="custom-select">
                    <option value={null}>Attendance</option>
                    <option value={1}>Present</option>
                    <option value={0}>Absent</option>
                </select>
            </div>
            <div className="col-md-2 align-self-center">
                <button onClick={this.onClickHandler} className="btn btn-block buttonStyle">Submit</button>
            </div>
        </div>
      </div>
    )
  }
}
