import React from 'react';
import ReactDOM from 'react-dom';
import {HashRouter, Route, Switch} from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';

//Components
import Home from './About/Dashboard';
import Announcement from './Announcement/Announcement';
import Accomplishments from './Accompishments/Index';
import Student from './Student/Student';
import grade9 from './Student/grade9';
import grade8 from './Student/grade8';
import grade10 from './Student/grade10';
import Login from './Login/LoginDashboard';

class App extends React.Component {
    
    constructor(props) {
        super(props);
        
        this.state = {
            isAdmin: false
        }

        this.isAuthenticated = () => {
            this.setState({isAdmin: true});
            localStorage.setItem('isAdmin', "true");
        }
    }
    
    render() {
        return(
            <HashRouter>
                <Switch>
                    <Route path ="/grade10" component={grade10}/>
                    <Route path ="/grade9" component={grade9}/>
                    <Route path ="/grade8" component={grade8}/>
                    <Route path ="/grade7" component={Student}/>
                    <Route path ="/login" component={() => <Login isAdmin={this.state.isAdmin} isAuthenticated={this.isAuthenticated}/>}/>
                    <Route path ="/accomplishments" component={Accomplishments}/>
                    <Route path ="/announcements" component={()=> <Announcement isAdmin={this.state.isAdmin}/>} />
                    <Route path ="/" component={Home}/>
                </Switch>
            </HashRouter>
        )
    }
}

ReactDOM.render(<App />, document.getElementById('root'));