import React from 'react';
import './styles.css';
import Pinpost from './Pinpost';
import FormFields from './FormFields';
import HOC from '../HOC/index';
import axios from 'axios';
import moment from 'moment';

class Announcement extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            announcements: [],
            toggleState: true
        }

        this.reloadState = () => {
            if(this.toggleState) this.setState({toggleState: false});
            else this.setState({toggleState: true});
            this.getAnnouncementFromDb();
            alert('Posted!');
        }

        this.sortArray = array => {
            for(let i = array.length; i > 0; i--) {
                 for(let j = 0; j < i - 1; j++) {
                    if(array[j].date < array[j + 1].date) {
                        let temp = array[j];
                        array[j] = array[j+1]
                        array[j+1] = temp;
                    }
                 }
            }
            return array;
        }

        this.getAnnouncementFromDb = () => {
            axios.get("http://sheltered-chamber-92543.herokuapp.com/announcements")
            .then((result) => {
                this.setState({announcements: this.sortArray(result.data)}); 
            })
            .catch((err) => {
                console.log(err);
            });
        }

    }

    componentDidMount() {
        axios.get("http://sheltered-chamber-92543.herokuapp.com/announcements")
        .then((result) => {
            this.setState({announcements: this.sortArray(result.data)}); 
        })
        .catch((err) => {
            console.log(err);
        });
    }
    
    render() {
        let announcements = this.state.announcements.map((val, ind) => {
            return <Pinpost 
                        title={val.title} 
                        date={moment(val.date).format("MMMM Do YYYY")} 
                        message={val.message} 
                        id={val._id} key={ind} 
                        reloadState={this.reloadState}
                        isAdmin = {this.props.isAdmin}
                        />
        });
        return (
            <HOC activeRoute="Announcement">
                {JSON.parse(localStorage.getItem('isAdmin')) ? <FormFields reloadState={this.reloadState}/> : null}
                {announcements}
            </HOC>
        );
    }
}

export default Announcement;
