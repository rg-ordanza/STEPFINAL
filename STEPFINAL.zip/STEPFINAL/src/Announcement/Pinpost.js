import React, { Component, Fragment } from 'react'
import axios from 'axios';
import qs from 'qs';


export default class Pinpost extends Component {
    constructor(props){
        super(props);

        this.state = {
            title: '',
            message: '',
            isAdmin: false
        }
        
        this.deletePost = () => {
            const config = {
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
            }
            let id = {id: this.props.id}
            axios.post("http://sheltered-chamber-92543.herokuapp.com/announcement/delete", qs.stringify(id) , config);
            this.props.reloadState('Remove!');
            alert('Remove!');
        }

        this.updatePost = () => {
            const config = {
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                }
              }
              let parameters = {id: this.props.id ,title: this.state.title, message: this.state.message}
              axios.post("http://sheltered-chamber-92543.herokuapp.com/announcement/update", qs.stringify(parameters) , config);
              alert('updated!');
        }

        this.onUpdateTitle = e => {
            this.setState({title: e.target.value});
        }

        this.onUpdateMessage = e => {
            this.setState({message: e.target.value});
        }
    }

    componentDidMount() {
        if(this.state.isAdmin) {
            let title = document.getElementById('announcement-title').value;
            let message = document.getElementById('announcement-message').value;
            this.setState({title, message});
        }

        let isAdministrator = localStorage.getItem('isAdmin');
        if(JSON.parse(isAdministrator)) {
            this.setState({isAdmin: true});
        }

        this.setState({
            title: this.props.title,
            message: this.props.message 
        })
    }

  render() {
    return (
        <div className="container-fluid mt-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-body">
                            {
                                this.state.isAdmin ? <Fragment>
                                                        <textarea value={this.state.title} onChange={this.onUpdateTitle}  id="announcement-title" className="form-control">
                                                        </textarea>
                                                        <small className="mt-2 text-secondary date">{this.props.date}</small>
                                                    </Fragment>
                                                   : 
                                                   <Fragment>
                                                        <h5 className="card-title">{this.props.title}</h5>
                                                        <small className="mt-2 text-secondary date">{this.props.date}</small>
                                                    </Fragment>

                            }
                            <hr />
                                {
                                    this.state.isAdmin ? <textarea value={this.state.message} onChange={this.onUpdateMessage} id="announcement-message" className="card-body form-control">
                                                        </textarea>
                                                    :
                                                        <div className="card-body">
                                                            {this.props.message}
                                                        </div>
                                }
                                {
                                    this.state.isAdmin ? <div className="announcement-buttons mt-2">
                                                        <button  onClick={this.updatePost} className="update-btn btn btn-sm btn-success d-inline-block mr-1">Update</button>
                                                        <button onClick={this.deletePost} className="delete btn btn-sm btn-warning">Delete</button>
                                                        </div> : null
                                }
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
  }
}

