import React, { Component } from 'react'
import axios from 'axios';
import qs from 'qs';

export default class FormFields extends Component {

  constructor(props) {
    super(props);
    this.state = {
      title: '',
      message: ''
    }
    
    this.titleChangeHandler = e => {
      this.setState({title: e.target.value});
    }

    this.messageChangeHandler = e => {
      this.setState({message: e.target.value});
    }

    this.submitData = () => {
      let parameters = {
          title: this.state.title,
          message: this.state.message
      }
        
      const config = {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
      
      axios.post("http://sheltered-chamber-92543.herokuapp.com/announcements", qs.stringify(parameters) , config)
        .then((result) => {
          this.setState({title: '', message: ''});
          this.props.reloadState();
        })
        .catch((err) => {
            console.log(err);
        })
    }
  }

  render() {
    return (
      <div className="container mt-4">
            <div className="row justify-content-center">
                <div className="col-md-6 card p-3 pl-4 pr-4">
                    <div className="form-group">
                        <input id="title" value={this.state.title} onChange={this.titleChangeHandler} className="form-control" type="text" placeholder="Enter Title" name="title"/>
                        <textarea id="message" value={this.state.message} onChange={this.messageChangeHandler} className="mt-2 form-control text-field" type="text" placeholder="Enter announcement..."/>                
                        <button onClick={this.submitData} className="buttonStyle mt-2 btn btn-block btn-sm btn-success">Post</button>
                    </div>
                </div>
            </div>
      </div>
    )
  }
}