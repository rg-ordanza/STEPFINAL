import React from 'react';
import Accompishments from './Accompishments';
import HOC from '../HOC/index';

const AccompishmentDashboard = () => {
    return (
        <div>
            <HOC activeRoute="Accompishments">
                <Accompishments />
            </HOC>
        </div>
    );
}

export default AccompishmentDashboard;
