import React from 'react';
import './styles.css';

const Accompishments = () => {
    return (
        <div className="accomplishments container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <p><span>San</span> Jose National High School is one of the fifteen schools in Region IV –A CALABARZON that implement
                    Science, Technology and Engineering Program (STE) special science curricular program funded by the
                    Department of Science and Technology (DOST). The program is under the close supervision of the school head
                    and STE coordinator, it is being monitored by the Division and Regional Science Supervisor and assessed and
                    evaluated by the Program Heads in DepEd Central Office. SJNHS-STE is in its eight year of implementation. It
                    started with two sections in 2010 having forty students each and sections are gradually increasing up to now. For
                    this year there are: three sections from grade 7 to grade 10. Three hundred fourteen are enrolled in this program
                    with thirty eight teachers teaching different subjects including the add ons (advanced subjects). The significance
                    increase in the number of enrollees each year signifies that the program is doing good. Achievements gained by
                    the program, teachers and students were helping the parents to decide to enroll their childrens in the program.
                    Currently they are housed in Nilo Building. The program is following the K to 12 program in teaching the subjects
                    - Filipino, English, Math, Science, AP, MAPEH, TLE and EsP. But SJNHS-STE included add ons such as
                    Environmental Science, Biotech, Consumer Chemistry, Advanced Physics and Research and Statistics. Aside
                    from some of the subject areas, the time allotment and unit credits are still patterned from DepEd Order No. 41,
                    s. 2004 and 31 s. 2012 (6 hours/week for Math and Science and 4 hours/week for other subjects including the
                    add ons). Instructions are still based from the K to 12 Program designed competencies. The acquisition of
                    learning materials fro the program just focuses on the K to 12 subject areas. We still have a problem in the
                    acquisition of learning materials in the add ons subjects. Acquisition of teaching tools, equipments and devices is
                    through the MOOE subject for regular accounting.</p>

                    <p><span>In</span> the first three years of the implementation the students were focused on the academic aspect of learning.
                    They were not able to join in different clubs and organizations. But in SY 2013-2014 since we are developing the
                    students holistically they were encouraged to join with different clubs and organizations until up to now. But the
                    students must not lost their focus in their academic development. In fact students were encourage to attend
                    different seminars, trainings, and workshop. Last March 2, 2015 - STEM Coordinator with five students from
                    Grade -9 STEM attended the Lecture Forum Of Professor Ada Yonath, A Nobel Peace Prize Laureate in
                    Chemistry at Teresa Yuchenco Auditorium, De La Salle University. This was an invitation of De La Salle
                    University. Professor Ada Yonath talked about RNA and DNA, the process of making proteins. The Hizon
                    Laboratories Inc. Is continuously sponsoring our students in the plant tour wherein students may apply their
                    learnings in ConChem and other related disciplines.</p>
                    
                    <p><span>STE</span> Program is specialized program that serve as a foundation for students who will pursue the STEM and
                    General Academic Strands. The program prepares the students to develop their full potentials especially in field
                    of Science, Technology and Engineering. In order to track the current condition and location of the graduates of
                    the program, the coordinator with the help of the Record Section made a tracker. Attached here are the lists of
                    students who graduated from the program and the school where they are currently taking their higher education.
                    In 2014-2015, a lot of the graduates was able to passed in different entrance exam of some known universities in
                    the country. In the University of the Philippines - 5 out of the 28 passed the exam, in De La Salle University - 6
                    out of 11 passed the exam, in Ateneo De Manila University - 2 out 2 was able to enter the school, in Lyceum of
                    the Philippines our lone test takers was the highest pointerin the entrance exam and in the University of Sto.
                    Tomas all of the 3 test takers made it. Some of the graduates were distributed to different State Universities like
                    University of Rizal System and Polythechnic University of the Philippines. In 2015, almost sixty percent of the graduates went to Engineering, Science and Math related courses. In 2017, more STE students get the
                    STEM/General Academic strands. In the same year, some of the first batch of the program already graduated.
                    Like Christine Anne S. Belen who graduated at Thai Nguyen University in Vietnam with recognition. Another one
                    who graduated with great achievement is Micah Alyanna Rivera, a recepient of DLSU Vaugirard Scholarship. The
                    same scholarship was also gained by Maverick Rivera and Angelo Edora both from the second batch of STE
                    Program graduates. More achievements from different batches were about to be recorded. One of them is
                    Rolyzza Ferrer who is doing good as a full scholar of De La Salle University. And the students who were currently
                    in the program were continuously gaining awards and recognitions in different contests at diffenrent level.</p>

                    <p><span>All</span> those achievements were because of the trainings and learnings that they got from their stay in the
                    SJNHS-STE program. As we talked to them they are always looking back to all the experiences they gained from
                    the program and their teachers. They are always very thankful, in fact Ms. Belen our Guest Speaker during the
                    2018 Completion Day, says that all her teachers that taught her really made a big impact in her life. Her leranings
                    from the program really help her to achieve more.</p>
                    
                </div>
            </div>            
        </div>
    );
}

export default Accompishments;
