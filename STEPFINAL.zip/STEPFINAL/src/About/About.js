import React, {Fragment} from 'react';
import './style.css';

const About = () => {
    return (
        <Fragment>
            <div className="cover-page">
            </div>
            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-12 text-center">
                        <div className="row justify-content-center">
                            <div className="col-md-5">
                                <div className="vision">
                                    <h3>Vision</h3>
                                    <p>We dream of Filipinos who passionately love their country and whose competencies and values enable them to realize their full potential and contribute meaningfully to building the nation. We are a learner-centered public institution, the Department of Education continuously improves itself to better serve its stakeholders.</p>
                                </div>
                            </div>
                                <div className="col-md-5">
                                    <div className="mission">
                                        <h3>Mission</h3>
                                        <p>To protect and promote the right of every Filipino to quality, equitable, culture-based and complete basic education where: Students learn in a child-friendly, gender-sensitive, safe and motivating environment Teachers facilitate learning and constantly nurture every learner administrators and staff, as stewards of the institution, ensure on enabling and supportive environment for effective learning to happen Family, community and other stakeholders are actively engaged and share responsibility for developing lifelong learners.</p>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-10 jumbotron mt-5">
                        <h2>About us</h2>
                        <p>Welcome to the digital age when parents need a student information management system that can effectively and efficiently deliver announcements about school activities to parents. With most forms of business conducted online and via mobile phones, we have significantly reduced our need for paper. Information comes to us instantly. From email to text message to social media, we are fully connected. Mobile devices have become the defacto means of conducting business. Many of us pay bills, bank, schedule events, shop, and even work directly from our cell phones. So why not have school announcements delivered in a paperless manner via a education management system.

</p>
                    </div>
                </div>
            </div>
        </Fragment>
            
    );
}

export default About;
