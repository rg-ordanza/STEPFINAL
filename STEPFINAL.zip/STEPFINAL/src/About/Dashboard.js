import React, { Component } from 'react'
import HOC from '../HOC/index';
import About from './About';

export default class Dashboard extends Component {
  render() {
    return (
        <HOC activeRoute={"Home"}>
            <About />
        </HOC>
    )
  }
}
